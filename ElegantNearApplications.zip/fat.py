import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

low_l = 0
low_h = 400

frames = 50000

fig, ax = plt.subplots()
anim_object, = plt.plot([], [], '-', lw=1)
plt.axis('equal')
ax.set_xlim(low_l, low_h)
ax.set_ylim(low_l, low_h)


b = 2
r = 10**15 + b
M = 10**27
G = 6.67*10**(-11)
c = 299792458
kord1 = 300
kord2 = 300
xdata, ydata = [], []

def muweng(t):
    global r
    alpha = G*M/(r*c**2)
    x0 = t
    y0 = t + b
    x2 = x0 * np.cos(alpha) - y0 * np.sin(alpha)
    y2 = x0 * np.sin(alpha) + y0 * np.cos(alpha)
    r = ((kord1-x2) ** 2 + (kord2 - y2) ** 2)**0.5
    xdata.append(x2)
    ydata.append(y2)
'''
def muweng1(t):
    global r
    alpha = G*M/(r*c**2)
    x0 = t
    y0 = t + b
    x2 = x0 * -np.cos(alpha) - y0 * np.sin(alpha)
    y2 = x0 * -np.sin(alpha) + y0 * np.cos(alpha)
    r = ((kord1-x2) ** 2 + (kord2 - y2) ** 2)**0.5
    xdata1.append(x2)
    ydata1.append(y2)
'''
def update(frame):
    muweng(frame)
    anim_object.set_data(xdata, ydata)
    return anim_object,

anim = FuncAnimation(fig, update, frames, interval=100)
plt.show()