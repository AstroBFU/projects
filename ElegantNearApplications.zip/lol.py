from numpy import*
from matplotlib.pyplot import*
R1=1.496*10**8#Числовые данные для расчётов взяты из
T1=3.156*10**7
R2=3.844*10**7
T2=2.36*10**6
N=1000.0

def X(t):
         return R1*cos(2*pi*t/T1)
def Y(t):
         return R1*sin(2*pi*t/T1)
def x(t):
         return R2*cos(2*pi*t/T2)
def y(t):
         return R2*sin(2*pi*t/T2)
t=[T1*i/N for i in arange(0,N,1)]
X=array([X(w) for w in t])
Y=array([Y(w) for w in t])
x=array([x(w) for w in t])
y=array([y(w) for w in t])
XG=X+x
YG=Y+y
figure()
title("Гелиоцентрическая орбита  Земли и Луны")
xlabel('$X(t_{k})$,$X_{g}(t_{k})$')
ylabel('$Y(t_{k})$,$Y_{g}(t_{k})$')
axis([-2.0*10**8,2.0*10**8,-2.0*10**8,2.0*10**8])
axis("equal")
plot(X,Y,label='Орбита Земли')
legend(loc='best')
grid(True)
show()
ax.fillbitwin