import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation
fig, ax = plt.subplots()
alpha = np.arange(-2*np.pi, 2*np.pi, 0.1) # Параметр
R = 1

x = R * np.cos(alpha)
y = R * np.sin(alpha)

plt.plot(x, y, ls='-', lw=5)

plt.axis('equal')

plt.show()